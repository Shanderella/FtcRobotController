package org.firstinspires.ftc.teamcode.teleop.Subsystems;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

public class Lift {

    private final DcMotorEx lift1;
    private final DcMotorEx lift2;

    private final Servo fourBar1, fourBar2, fourBar3, fourBar4;

    //Tune
    public static double FOURBAR_DEPLOY_POS = 1.0;
    public static double FOURBAR_STOW_POS   = 0.0;

    public static long FOURBAR_SETTLE_MS = 350;

    //Target for lift1
    public static int LIFT_TARGET_TICKS = 2000;


    public static double LIFT_POWER = 1.0;

    private boolean liftStartEvent = false;
    private boolean liftKilledEvent = false;

    private enum State { IDLE, DEPLOYING_4BAR, LIFTING, DONE }
    private State state = State.IDLE;

    private final ElapsedTime stateTimer = new ElapsedTime();

    public Lift(HardwareMap hardwareMap) {
        lift1 = hardwareMap.get(DcMotorEx.class, "lift1");
        lift2 = hardwareMap.get(DcMotorEx.class, "lift2");

        fourBar1 = hardwareMap.get(Servo.class, "4bar1");
        fourBar2 = hardwareMap.get(Servo.class, "4bar2");
        fourBar3 = hardwareMap.get(Servo.class, "4bar3");
        fourBar4 = hardwareMap.get(Servo.class, "4bar4");

        lift1.setDirection(DcMotorSimple.Direction.REVERSE);
        lift2.setDirection(DcMotorSimple.Direction.FORWARD);

        lift1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        lift2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);


        lift1.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        lift1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);


        lift2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        //setFourBar(false);
        fourBar1.setPosition(0);
        fourBar2.setPosition(0);
        fourBar3.setPosition(0);
        fourBar4.setPosition(0);
    }


    public void startSequence() {

        if (state == State.DEPLOYING_4BAR || state == State.LIFTING) return;


        setFourBar(true);


        stateTimer.reset();
        state = State.DEPLOYING_4BAR;


        liftStartEvent = true;
        liftKilledEvent = false;
    }


    public void update() {
        switch (state) {
            case IDLE:

                break;

            case DEPLOYING_4BAR:

                if (stateTimer.milliseconds() >= FOURBAR_SETTLE_MS) {

                    beginLiftToTarget();
                    state = State.LIFTING;
                }
                break;

            case LIFTING:

                if (!lift1.isBusy()) {
                    stopMotors();
                    state = State.DONE;
                } else {

                    lift2.setPower(-LIFT_POWER);
                }
                break;

            case DONE:

                break;
        }
    }

    private void beginLiftToTarget() {

        lift1.setTargetPosition(LIFT_TARGET_TICKS);
        lift1.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        lift1.setPower(LIFT_POWER);


        lift2.setPower(-LIFT_POWER);
    }

    private void stopMotors() {
        lift1.setPower(0);
        lift2.setPower(0);

        lift1.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    }

    public void killAll() {

        stopMotors();

        setFourBar(false);

        state = State.IDLE;

        liftKilledEvent = true;
    }

//Mirror logic
    private void setFourBar(boolean deployed) {
        double a = deployed ? FOURBAR_DEPLOY_POS : FOURBAR_STOW_POS;
        double b = 1.0 - a;


        fourBar1.setPosition(0.55);
        fourBar2.setPosition(1);
        fourBar3.setPosition(0.58);
        fourBar4.setPosition(1);
    }


    public boolean consumeLiftStartEvent() {
        if (liftStartEvent) {
            liftStartEvent = false;
            return true;
        }
        return false;
    }

    public boolean consumeLiftKilledEvent() {
        if (liftKilledEvent) {
            liftKilledEvent = false;
            return true;
        }
        return false;
    }
}
