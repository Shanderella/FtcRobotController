package org.firstinspires.ftc.teamcode.teleop;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;


@TeleOp(name = "Lift_Down", group = "V7")
public class Lift_Down extends OpMode {



    private DcMotorEx lift1, lift2;
    private boolean liftActivate = false;

    @Override
    public void init() {


        lift1 = hardwareMap.get(DcMotorEx.class, "lift1");
        lift2 = hardwareMap.get(DcMotorEx.class, "lift2");
        lift1.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
        lift2.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
        }

    @Override
    public void loop() {
        liftTask();
    }

    private void liftTask() {
        if (gamepad1.triangle) {
            liftActivate = true;
            lift1.setPower(1);
            lift2.setPower(1);
        }
    }
}
