package org.firstinspires.ftc.teamcode.teleop.Subsystems;

import com.qualcomm.hardware.rev.RevBlinkinLedDriver;
import com.qualcomm.robotcore.hardware.HardwareMap;

public class Blinkin {
    private final RevBlinkinLedDriver blinkin;


    private RevBlinkinLedDriver.BlinkinPattern readyBase =
            RevBlinkinLedDriver.BlinkinPattern.SHOT_WHITE;
    private RevBlinkinLedDriver.BlinkinPattern notReadyBase =
            RevBlinkinLedDriver.BlinkinPattern.RED_ORANGE;


    private long flashUntilMs = 0;
    private RevBlinkinLedDriver.BlinkinPattern flashPattern =
            RevBlinkinLedDriver.BlinkinPattern.WHITE;


    private boolean liftKilledLatched = false;
    private RevBlinkinLedDriver.BlinkinPattern liftKilledPattern =
            RevBlinkinLedDriver.BlinkinPattern.CONFETTI;


    private boolean shooterReady = false;

    public Blinkin(HardwareMap hardwareMap) {
        blinkin = hardwareMap.get(RevBlinkinLedDriver.class, "blinkin");
        blinkin.setPattern(notReadyBase);
    }



    public void setShooterReady(boolean ready) {
        shooterReady = ready;
    }

    public void onShot() {
        flashPattern = RevBlinkinLedDriver.BlinkinPattern.RED;
        flashUntilMs = System.currentTimeMillis() + 200;
    }

    public void onIntake() {
        flashPattern = RevBlinkinLedDriver.BlinkinPattern.VIOLET;
        flashUntilMs = System.currentTimeMillis() + 200;
    }

    public void onLiftStart() {
        liftKilledLatched = false;
        flashPattern = RevBlinkinLedDriver.BlinkinPattern.RAINBOW_LAVA_PALETTE;
        flashUntilMs = System.currentTimeMillis() + 15000;
    }

    public void onLiftKilled() {
        liftKilledLatched = true;
    }



    public void update() {
        long now = System.currentTimeMillis();


        if (liftKilledLatched) {
            blinkin.setPattern(liftKilledPattern);
            return;
        }


        if (now < flashUntilMs) {
            blinkin.setPattern(flashPattern);
            return;
        }

        blinkin.setPattern(shooterReady ? readyBase : notReadyBase);
    }
}
