package org.firstinspires.ftc.teamcode.teleop;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "Decode_1", group = "V7")
public class Decode_1 extends OpMode {
    private double shooterPower = -0.4;

    private DcMotorEx lfm, lbm, rfm, rbm;
    private DcMotorEx intake, sr, sl, lift;
    private boolean liftActivate = false;
    private CRServo tl, bl;
    private Servo micro;
    private long lastRumbleTime = 0;
    private final long rumbleCooldown = 500;

    @Override
    public void init() {
        telemetry.addLine("Initializing...");

        lfm = hardwareMap.get(DcMotorEx.class, "lfm");
        lbm = hardwareMap.get(DcMotorEx.class, "lbm");
        rfm = hardwareMap.get(DcMotorEx.class, "rfm");
        rbm = hardwareMap.get(DcMotorEx.class, "rbm");

        intake = hardwareMap.get(DcMotorEx.class, "intake");
        sr = hardwareMap.get(DcMotorEx.class, "sr");
        sr.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
        sr.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
        sl = hardwareMap.get(DcMotorEx.class, "sl");

        tl = hardwareMap.get(CRServo.class, "tl");
        bl = hardwareMap.get(CRServo.class, "bl");
        micro = hardwareMap.get(Servo.class, "micro");

        lift = hardwareMap.get(DcMotorEx.class, "lift");
        lift.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);

        lfm.setDirection(DcMotorSimple.Direction.REVERSE);
        lbm.setDirection(DcMotorSimple.Direction.REVERSE);
        rfm.setDirection(DcMotorSimple.Direction.FORWARD);
        rbm.setDirection(DcMotorSimple.Direction.FORWARD);

        sl.setDirection(DcMotorSimple.Direction.REVERSE);

        for (DcMotorEx motor : new DcMotorEx[]{lfm, lbm, rfm, rbm, intake, sr, sl}) {
            motor.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
        }

        telemetry.addLine("Ready");
        telemetry.update();
    }
    private static final double TICKS_PER_REV = 28.0;

    @Override
    public void loop() {
        driveTask();
        intakeTask();
        launcherTask();
        servoTask();
        liftTask();
        microTask();
        rpmTelemetryTask();

        double s1VelocityTicksPerSec = sr.getVelocity();
        double s1RPM = (s1VelocityTicksPerSec / TICKS_PER_REV) * 60.0;

        telemetry.addData("Lift Active", liftActivate);
        telemetry.addData("Shooter Power", shooterPower);
        telemetry.addData("S1 RPM", String.format("%.1f", s1RPM));

        telemetry.update();
    }

    private void rpmTelemetryTask() {
        double ticksPerSec = sr.getVelocity();
        double rpm = (ticksPerSec / TICKS_PER_REV) * 60.0;
        if (rpm <= -2914) {
            long now = System.currentTimeMillis();
            if (now - lastRumbleTime > rumbleCooldown) {
                gamepad1.rumble(500);
                lastRumbleTime = now;
            }
        }
    }

    private void driveTask() {
        double drive = gamepad1.left_stick_y;
        double strafe = -gamepad1.left_stick_x;
        double turn = -gamepad1.right_stick_x;

        double deadzone = 0.05;
        if (Math.abs(drive) < deadzone) drive = 0;
        if (Math.abs(strafe) < deadzone) strafe = 0;
        if (Math.abs(turn) < deadzone) turn = 0;

        double magnitude = Math.hypot(strafe, drive);
        double angle = Math.atan2(drive, strafe);

        double snapThreshold = Math.toRadians(10);
        if (magnitude > 0.2) {
            if (Math.abs(angle - Math.PI / 2) < snapThreshold) {
                strafe = 0;
                drive = magnitude;
            } else if (Math.abs(angle + Math.PI / 2) < snapThreshold) {
                strafe = 0;
                drive = -magnitude;
            } else if (Math.abs(angle) < snapThreshold) {
                strafe = magnitude;
                drive = 0;
            } else if (Math.abs(Math.abs(angle) - Math.PI) < snapThreshold) {
                strafe = -magnitude;
                drive = 0;
            }
        }

        double lfPower = drive + strafe + turn;
        double lbPower = drive - strafe + turn;
        double rfPower = drive - strafe - turn;
        double rbPower = drive + strafe - turn;

        double max = Math.max(Math.abs(lfPower), Math.max(Math.abs(lbPower),
                Math.max(Math.abs(rfPower), Math.abs(rbPower))));
        if (max > 1.0) {
            lfPower /= max;
            lbPower /= max;
            rfPower /= max;
            rbPower /= max;
        }

        lfm.setPower(lfPower);
        lbm.setPower(lbPower);
        rfm.setPower(rfPower);
        rbm.setPower(rbPower);
    }

    private void intakeTask() {
        if (gamepad1.right_bumper) {
            intake.setPower(-1.0);
        } else if (gamepad1.left_bumper) {
            intake.setPower(0.5);
        } else {
            intake.setPower(0);
        }
    }

    private void launcherTask() {
        if (gamepad1.dpad_up) {
            shooterPower = -0.4;//Default
        } else if (gamepad1.dpad_right) {
            shooterPower = -1;//Max
        } else if (gamepad1.dpad_down) {
            shooterPower = -0.45;//Medium
        } else if (gamepad1.dpad_left) {
            shooterPower = -0.5;//Faster
        }

        //Fire away
        if (gamepad1.right_trigger > 0.1) {
            sr.setPower(shooterPower);
            sl.setPower(shooterPower);
        } else {
            sr.setPower(0);
            sl.setPower(0);
        }
        if (gamepad1.right_stick_button) {
            sr.setPower(0.2);
        }
        telemetry.update();
    }

    private void servoTask() {
        if (gamepad1.x) {
            tl.setPower(-1.0);
            bl.setPower(1.0);
        } else if (gamepad1.a) {
            tl.setPower(1.0);
            bl.setPower(-1.0);
        } else {
            tl.setPower(0);
            bl.setPower(0);
        }
    }

    private void liftTask() {
        if (gamepad1.touchpad && !liftActivate) {
            liftActivate = true;
            lift.setPower(1.0);
        }

        if (gamepad1.triangle && liftActivate) {
            liftActivate = false;
            lift.setPower(0);
        }
    }

    private void microTask() {
        if (gamepad1.left_stick_button) {
            micro.setPosition(0.7);
        }
    }
}
