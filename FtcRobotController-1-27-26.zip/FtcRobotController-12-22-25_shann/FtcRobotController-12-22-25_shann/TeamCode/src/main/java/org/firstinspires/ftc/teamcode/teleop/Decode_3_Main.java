package org.firstinspires.ftc.teamcode.teleop;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import org.firstinspires.ftc.teamcode.teleop.Subsystems.Shooter;
import org.firstinspires.ftc.teamcode.teleop.Subsystems.Intake;
import org.firstinspires.ftc.teamcode.teleop.Subsystems.Blinkin;
import org.firstinspires.ftc.teamcode.teleop.Subsystems.Lift;

@TeleOp(name = "Decode_3", group = "V7")
public class Decode_3_Main extends OpMode {

    private DcMotorEx lfm, lbm, rfm, rbm;
    private Shooter shooter;
    private Intake intake;
    private Blinkin blinkin;
    private Lift lift;

    private boolean shooterWasReady = false;

    private boolean squareWasPressed = false;
    private boolean touchpadWasPressed = false;

    private boolean rbWasPressed = false;

    @Override
    public void init() {
        telemetry.addLine("Initializing...");

        lfm = hardwareMap.get(DcMotorEx.class, "lfm");
        lbm = hardwareMap.get(DcMotorEx.class, "lbm");
        rfm = hardwareMap.get(DcMotorEx.class, "rfm");
        rbm = hardwareMap.get(DcMotorEx.class, "rbm");

        shooter = new Shooter(hardwareMap);
        intake  = new Intake(hardwareMap);
        lift    = new Lift(hardwareMap);
        blinkin = new Blinkin(hardwareMap);

        lfm.setDirection(DcMotorSimple.Direction.REVERSE);
        lbm.setDirection(DcMotorSimple.Direction.REVERSE);
        rfm.setDirection(DcMotorSimple.Direction.FORWARD);
        rbm.setDirection(DcMotorSimple.Direction.FORWARD);

        for (DcMotorEx motor : new DcMotorEx[]{lfm, lbm, rfm, rbm}) {
            motor.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
        }

        telemetry.addLine("Ready");
        telemetry.update();
    }

    @Override
    public void loop() {
        driveTask();
        intakeTask();
        liftTask();
        shooterTask();

        intake.update();
        lift.update();

        blinkin.setShooterReady(shooter.isReady());

        if (shooter.consumeShotEvent())    blinkin.onShot();
        if (intake.consumeIntakeEvent())   blinkin.onIntake();
        if (lift.consumeLiftStartEvent())  blinkin.onLiftStart();
        if (lift.consumeLiftKilledEvent()) blinkin.onLiftKilled();

        blinkin.update();

        telemetry.addData("ShooterReady", shooter.isReady());
        telemetry.addData("RPM", shooter.getRPM());
        telemetry.addData("Accel", shooter.getAcceleration());
        telemetry.addData("balls", intake.getBallCount());
        telemetry.update();
    }

    private void driveTask() {
        double drive  = gamepad1.left_stick_y;
        double strafe = -gamepad1.left_stick_x;
        double turn   = -gamepad1.right_stick_x;

        double deadzone = 0.05;
        if (Math.abs(drive)  < deadzone) drive  = 0;
        if (Math.abs(strafe) < deadzone) strafe = 0;
        if (Math.abs(turn)   < deadzone) turn   = 0;

        double lf = drive + strafe + turn;
        double lb = drive - strafe + turn;
        double rf = drive - strafe - turn;
        double rb = drive + strafe - turn;

        double max = Math.max(Math.abs(lf),
                Math.max(Math.abs(lb),
                        Math.max(Math.abs(rf), Math.abs(rb))));

        if (max > 1.0) {
            lf /= max; lb /= max; rf /= max; rb /= max;
        }

        lfm.setPower(lf);
        lbm.setPower(lb);
        rfm.setPower(rf);
        rbm.setPower(rb);
    }


    private void intakeTask() {
        boolean rbNow = gamepad1.right_bumper;
        boolean lbNow = gamepad1.left_bumper;

        //Session reset
        if (!rbNow && rbWasPressed) {
            intake.resetSession();
        }
        rbWasPressed = rbNow;

        if (rbNow) {
            intake.run();       //Should auto-stop
        } else if (lbNow) {
            intake.reverse();
        } else {
            intake.stop();
        }
    }


    private void liftTask() {
        boolean touchpadNow = gamepad1.touchpad;
        if (touchpadNow && !touchpadWasPressed) {
            lift.startSequence();
        }
        touchpadWasPressed = touchpadNow;

        if (gamepad1.triangle) {
            lift.killAll();
        }
    }


    private void shooterTask() {
        shooter.setManualBackfeed(gamepad1.left_trigger > 0.2);

        boolean squareNow = gamepad1.square;
        if (squareNow && !squareWasPressed) {
            shooter.pulseTransferForward();
        }
        squareWasPressed = squareNow;

        if (gamepad1.right_trigger > 0.2) {
            shooter.spinUp();
        } else {
            shooter.setTriggerHeld(false);
        }

        if (gamepad1.cross) {
            shooter.fire();
        }

        shooter.update();

        boolean ready = shooter.isReady();
        if (ready && !shooterWasReady) {
            gamepad1.rumble(250);
        }
        shooterWasReady = ready;
    }
}
